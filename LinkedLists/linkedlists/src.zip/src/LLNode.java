
/*
    Author: April Bollinger
    Program: LLNode (to be used with linkedlist.java)
    Purpose: This program sets up the structure of the nodes used in the linkedlist
*/

public class LLNode {

    int data;
    LLNode next;
    LLNode tail;
    LLNode head;
 
    public void construct(LLNode head, LLNode tail, LLNode next) {
        this.head = head;
        this.tail = tail;
        this.next = next;
    }

	LLNode(int x) {
        data = x;
        next = null;
	}

	

}